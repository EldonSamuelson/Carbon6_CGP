#!/usr/bin/env python3
import cgitb
import cx_Oracle
cgitb.enable(format='text')
from jinja2 import Environment, FileSystemLoader

#render the template
def print_html():
    env = Environment(loader=FileSystemLoader('.'))
    temp = env.get_template('castles_3_1.html')
    inpName = "Miles O'Brien"
    inpLocation = "Deep Space 9"
    inpCastles = castleHtml()
    print(temp.render(name = inpName, loc = inpLocation, castles = inpCastles))

def castleHtml():
    conn = cx_Oracle.connect("student/train@geoslearn")
    c = conn.cursor()
    c.execute("SELECT * FROM ancient_castles")
    html = ''
    for row in c:
        html = html + row[0] + " - " + row[1] + '<br>'
    conn.close()
    return html

#run
if __name__ == '__main__':
    print_html()

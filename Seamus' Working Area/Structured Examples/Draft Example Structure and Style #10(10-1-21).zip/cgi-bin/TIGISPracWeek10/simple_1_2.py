#!/usr/bin/env python3
from jinja2 import Template

inpName = input("Enter your name here: ")
tm = Template("Hello {{ name }}!")
msg = tm.render(name=inpName)
print(msg)

#Asks for a user name and generates a message string, which is printed to the user.The {{}} contains the variable. This ONLY operates in terminals/cmd line!

#!/usr/bin/env python3
 
import cx_Oracle                # Links oracle database with python
import cgi                      # Import modules for CGI handling
import cgitb     
from jinja2 import Environment, FileSystemLoader            # For templating, avoids hardcoding html  
cgitb.enable(format='text/html')

with open("../../oracle",'r') as pwf:                         
    pw = pwf.read().strip()                                 # Reads oracle password as a sepatate file outside pubic_html for security purposes  

# Create instance of FieldStorage to store user's choice in the forms
form = cgi.FieldStorage()

mylist1=[]         # To Store User's Choice (1,2,3........)
mylist2=[]         # To Store information from the database as per radiobutton choice 
mylist3=[]         # To Store information to be rendered in the final table (using html template)           

# Get data from radiobutton

if form.getvalue('Radiochoice'):
   user_choice = form.getvalue('Radiochoice')
else:
   pass

# Get data from Zones Form 2
if form.getvalue('Zones_Multicombo'):
    subject = form.getvalue('Zones_Multicombo')
    # checks if a user selects single choice and appends to the list
    if (type(subject))==str:
        mylist1.append(int(subject))
    # if a user selects multiple choices (subject will then belong to a datatype like tuple/list) and appends to the list
    else:
        for row in subject[0 : : 1]:
            mylist1.append(row)
else:
   subject = "Not entered"
   pass

conn = cx_Oracle.connect(dsn="geoslearn",user="s1624036",password=pw)   # Function for connecting to the oracle database
c = conn.cursor()
# checking each condition and appending the information from the database accordingly
if user_choice=='Demographic':
    c.execute("SELECT ZONENAME, EDIRANK, AREAHA, POP, POPPERHA FROM EDITEST")
    for row in c:
        mylist2.append(row)
    fields=("ZONE NAME", "EDI RANK", "AREA (ha)", "POPULATION", "POPULATION DENSITY")
    conn.close
elif user_choice=='Environmental':
    c.execute("SELECT ZONENAME, EDIRANK, TREECOUNT, TREESPERHA, MEANDBH, JUVCOUNT, JUVPERHA, SPECIES, SPECIESPERTREE FROM EDITEST")
    for row in c:
        mylist2.append(row)
    fields=("ZONE NAME", "EDI RANK", "TOTAL TREE COUNT", "TREES (PER ha)", "MEAN DBH (cm)", "JUVENILE TREE COUNT", "JUVENILE TREES (PER ha)", "TOTAL TREE SPECIES COUNT", "TREE SPECIES (PER ha)")
    conn.close
elif user_choice=='Tree_Percentage':
    c.execute("SELECT ZONENAME, EDIRANK, PERCHIGH, PERCMED, NFIPERC FROM EDITEST")
    for row in c:
        mylist2.append(row)
    fields=("ZONE NAME", "EDI RANK", "DENSE TREES (%)", "SCATTERED TREES (%)", "WOODLAND COVER (%)")
    conn.close
elif user_choice=='Tree_Hectare':
    c.execute("SELECT ZONENAME, EDIRANK, HIGHHA, MEDHA, NFIHA FROM EDITEST")
    for row in c:
        mylist2.append(row)
    fields=("ZONE NAME", "EDI RANK", "DENSE TREES (ha)", "SCATTERED TREES (ha)", "WOODLAND COVER (ha)")
    conn.close
else:
    conn.close
    pass

for i in mylist1:
    mylist3.append(mylist2[int(i)-1])       # i-1, since user choice starts with 1 and not 0 

def print_html():                           # function for rendering the table using versionx.html template
        env = Environment(loader=FileSystemLoader('.'))
        temp = env.get_template('zonestatistics.html')
        inpEDI=mylist3                      # data from the database
        inpHeading=fields                   # column heading (different for each radio button option)
        print(temp.render(heading = inpHeading, data=inpEDI))

if __name__ == '__main__':
	print_html()

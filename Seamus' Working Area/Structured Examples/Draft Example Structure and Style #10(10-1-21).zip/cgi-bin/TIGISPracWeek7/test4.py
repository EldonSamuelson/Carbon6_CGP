#!/usr/bin/env python3
import cgi
import cgitb
import cx_Oracle
cgitb.enable()

print("Content-Type: text/html\n")

print("<!DOCTYPE html>")
print("<head>")
print("<title>Test4.py - This is the Crop Report</title>")
print("</head>")

print("<body>")
conn = cx_Oracle.connect("student/train@geoslearn")
c = conn.cursor()
c.execute('SELECT * FROM GISTEACH.CROPS')
for row in c:
    print(row[0], "-", row[1])
print("<p>This is test4.py, which imports SQL tables from GISTEACH</p>")
print("</body>")
print("</html>")

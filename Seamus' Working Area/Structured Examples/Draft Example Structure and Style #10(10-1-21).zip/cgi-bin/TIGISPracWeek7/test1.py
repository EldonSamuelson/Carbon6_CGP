#!/usr/bin/env python3
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/plain\n")
print("Hello man")
print("This is my first python script in cgibin!")
print("I'm afraid you are just gonna have to press back to leave here")
print("...or y'know, just stay here forever.")
print("Note to self; 'chmod u+x <filename>.py' to make them executable, otherwise they don't open properly") 

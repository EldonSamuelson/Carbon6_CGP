#!/usr/bin/env python3
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/html\n")
print("<!DOCTYPE html>")
print("<head>")
print("<title>This is the pagetitle</title>")
print("</head>")
print("<body>")
print("<h2>This is a text title</h2>")
print("</body>")
print("</html>")
print("<p>Hello man</p>")
print("<p>This is my 3rd  python script in cgibin! This differs from the previous as it is in html and has the proper !DOCTYPE, headings, title, and h2, etc.</p>")
print("it just means that instead of just writing it purely through html as the Index and Welcome page, I have to put 'print' before  everything. so that means for this simple text page it's pointless, but wait until the later test examples...")
print("<p>I'm afraid you are just gonna have to press back to leave here</p>")
print("...or y'know, just stay here forever.")

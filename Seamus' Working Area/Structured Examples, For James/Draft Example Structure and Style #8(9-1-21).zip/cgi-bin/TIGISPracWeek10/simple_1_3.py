#!/usr/bin/env python3
from jinja2 import Template

inpName = 'Florian'
inpAge = 23
inpTeam = 'Hibernian'

tm = Template("My name is {{name}}, I play for {{team}} and I am {{age}}")
msg = tm.render(name=inpName, age=inpAge, team=inpTeam)

print(msg)

#Template that renders 3 variables, hardcoded instead of asking the user. The {{}} contains the variable. This ONLY operates in terminals/cmd line!

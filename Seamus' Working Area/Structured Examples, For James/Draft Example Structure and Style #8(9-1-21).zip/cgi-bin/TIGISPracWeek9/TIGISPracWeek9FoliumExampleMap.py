#!/usr/bin/env python3
import cgi
import cgitb
import folium

#Some Interesting Locations
drummondSt = [55.948162, -3.184111]
kb = [55.923998, -3.174950]
mySt = [55.943876, -3.2354571]

#The Folium map bit
map = folium.Map(location=drummondSt,zoom_start=5,tiles='Stamen Toner')
folium.Marker(drummondSt,popup="<b>This is the School of Geosciences building, on Drummond Street!</b>").add_to(map)
folium.Marker(kb,popup="This is the Edinburgh University King's Buildings!").add_to(map)
folium.Marker(mySt,popup="<b>This is my street where I'm writing this code!</b>").add_to(map)

print("Content-type: text/html\n")
print(map.get_root().render())

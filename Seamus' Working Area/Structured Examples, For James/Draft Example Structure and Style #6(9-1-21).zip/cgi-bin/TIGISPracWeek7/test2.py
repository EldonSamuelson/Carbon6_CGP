#!/usr/bin/env python3
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/html\n")
print("<p>Hello man</p>")
print("<p>This is my second python script in cgibin! This differs from the first as it is in html rather than plaintext.</p>")
print("it just means I have to add 'p'text'/p'(with the little arrows) within the print statements to make new lines, but also means I can make things in <b>bold</b> as HTML allows")
print("<p>I'm afraid you are just gonna have to press back to leave here</p>")
print("...or y'know, just stay here forever.")

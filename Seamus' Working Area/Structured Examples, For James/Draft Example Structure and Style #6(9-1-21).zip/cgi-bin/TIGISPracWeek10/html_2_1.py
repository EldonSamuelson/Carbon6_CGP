#!/usr/bin/env python3
import cgitb
cgitb.enable(format='text')
from jinja2 import Environment, FileSystemLoader

#render the template
def print_html():
    env = Environment(loader=FileSystemLoader('.'))
    temp = env.get_template('html_2_1.html')
    inpName = "Miles O'Brien"
    inpAge = 34
    inpOrigin = 'Deep Space 9'
    print(temp.render(name = inpName, age = inpAge, origin = inpOrigin))

#run
if __name__ == '__main__':
    print_html()

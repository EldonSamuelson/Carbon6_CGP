#!/usr/bin/env python3
import cgi
import cgitb
import folium
import cx_Oracle

#The Folium map bit
map = folium.Map(location=[55.9486,-3.2008],zoom_start=6,tiles='Stamen Toner')

#The Oracle database bit
conn = cx_Oracle.connect("student/train@geoslearn")
c = conn.cursor()

c.execute("select castle,LAT_Y,LON_X from ancient_castles")

for row in c:
    folium.Marker(row[1:],popup=row[0]).add_to(map)

print("Content-type: text/html\n")
print(map.get_root().render())
